package controllers;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import play.mvc.*;
import play.data.validation.*;

import models.*;

public class Application extends Controller {
    
    @Before
    static void addUser() {
        User user = connected();
        if(user != null) {
            renderArgs.put("user", user);
        }
    }
    
    static User connected() {
        if(renderArgs.get("user") != null) {
            return renderArgs.get("user", User.class);
        }
        String username = session.get("user");
        if(username != null) {
            return User.find("byUsername", username).first();
        } 
        return null;
    }
    
    // ~~

    public static void index() {
        if(connected() != null) {
            Hotels.index();
        }
        render();
    }
    
    public static void register() {
        render();
    }
    
    public static void saveUser(@Valid User user, String verifyPassword) {
        validation.required(verifyPassword);
        validation.equals(verifyPassword, user.password).message("Your password doesn't match");
        if(validation.hasErrors()) {
            render("@register", user, verifyPassword);
        }
        user.create();
        session.put("user", user.username);
        flash.success("Welcome, " + user.name);
        Hotels.index();
    }
    
    public static void login(String username, String password) {
        User user = User.find("byUsernameAndPassword", username, password).first();
        if(user != null) {
            session.put("user", user.username);
            flash.success("Welcome, " + user.name);
            Hotels.index();         
        }
        // Oops
        flash.put("username", username);
        flash.error("Login failed");
        index();
    }
    
    public static void logout() {
        session.clear();
        index();
    }
    
    public static void saveCar(Traffic car) {
    	 System.out.println("---------------------------:"+car.id);
        car.save();
        System.out.println("---------------------------:"+car.id);
        list();
    }
    
    public static void traffic() {
        render();
    }
    
    public static void list() {
    	 List<Traffic> cars = Traffic.findAll();
    	 System.out.println("---------------------------:get all cars"+(connected()==null));
        render(cars);
    }
    
    public static void show(Long id) {
    	Traffic car = Traffic.findById(id);
        render(car);
    }
    
    public static void uploadPhoto(String title, File photo) {
    	  System.out.println("@@@@@@@@@@@:"+photo.getPath());
    	  File re = new File("F:\\Mystuff\\play-1.2.1\\1212\\samples-and-tests\\booking\\public"); 
    	  photo.renameTo(new File(re,  photo.getName())); 
    	  String filename = photo.getName();
    	  render(filename);
    }
    
    public static File download(String filename) {
    	if(connected()==null){
    		register();
    		//return null; 
    	}
    	File re = new File("F:\\Mystuff\\play-1.2.1\\1212\\samples-and-tests\\booking\\public\\"+filename); 
  	    return re; 
   }

}