package models;

import play.db.jpa.*;
import play.data.validation.*;
import javax.persistence.*;
import java.math.*;

@Entity
public class Traffic extends Model {
    
	public String trafficid;
	public String traffic_num;
	public String traffic_type;
	public String driver_name;
	public String buy_time;
	public String lastcheckdate;
	public String nextcheckdate;
	public String kilometers;
	public String month_distance;
	public String traffic_status;


    
    
}
