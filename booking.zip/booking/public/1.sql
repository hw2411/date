insert into base_co (COCODE, CONAME, COVALUE, REMARK, ORDERCODE, CLASSFICATION, COTYPE, RECORDERTIME, RECORDERDESC, RECORDERCODE, CLASSFICATION2)
values ('USEOWNENCODE', '是否启用自有编码', '1', '是否启用自有编码', '40', '安全与日志', '0', to_date('23-09-2013 16:12:06', 'dd-mm-yyyy hh24:mi:ss'), '超级管理员', 'admin', '安全');

